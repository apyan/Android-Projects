# tastette
A cooking recipe Android application for software engineer practices.

Etymology:<br/>
tastette -> tasty + ette (etiquette)<br/>
OR<br/>
tastette -> taste + it

Android Architecture Diagram (MVP):<br/>
https://docs.google.com/drawings/d/1rrDH4dzq_2WDaxfCEO3s7PYoDkonKPZcLSHaHvvLgwE/edit?usp=sharing
