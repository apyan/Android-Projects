package com.apyan.tastette.presenter

object SearchFragmentPresenter {
}