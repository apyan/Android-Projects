package com.apyan.tastette.presenter

object HomeFragmentPresenter {
}