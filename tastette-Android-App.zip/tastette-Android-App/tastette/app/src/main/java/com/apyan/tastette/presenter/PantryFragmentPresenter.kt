package com.apyan.tastette.presenter

object PantryFragmentPresenter {
}