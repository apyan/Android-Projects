# Demo-Android-Code
Demo Code

Character Viewer - View characters (Few crashes/Unstable for tablet!)

FoodTrucks - View food trucks

This will be updated from time to time.
