# Personal-Capital-Android-App
An Android app that views article contents from the Personal Capital company.

(Deprecated/Discontinued - Sample Only)
