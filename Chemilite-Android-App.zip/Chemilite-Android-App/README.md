# Chemilite-Android-App
A basic chemistry learning mobile application.

(Deprecated/Discontinued - Sample Only)
