package com.personaldev.car_rental.carrental;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ScreenCarRentalPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen_car_rental_page);
    }
}
